package org.vmart.validator.routines;

public class EmailValidator {

}
