package org.vmart;




class VyntramartApplicationTests {

	
	void contextLoads() {
	}

}
