package org.apache.commons.lang.exception;

public class ExceptionUtils {

	public static Throwable getRootCause(Exception e) {
		
		return null;
	}

}
